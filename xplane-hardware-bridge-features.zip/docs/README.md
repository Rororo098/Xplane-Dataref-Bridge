# XPlane Dataref Bridge - Complete Documentation

## 📖 Table of Contents

1. [Introduction](#introduction)
2. [System Architecture](#system-architecture)
3. [Installation](#installation)
4. [Quick Start Guide](#quick-start-guide)
5. [Core Concepts](#core-concepts)
6. [Input Mapping](#input-mapping)
7. [Output Mapping](#output-mapping)
8. [Conditional Logic](#conditional-logic)
9. [Axis Calibration](#axis-calibration)
10. [Sequences & Macros](#sequences--macros)
11. [Arduino/ESP32 Integration](#arduinoesp32-integration)
12. [Troubleshooting](#troubleshooting)

---

## Introduction

### What is XPlane Dataref Bridge?

XPlane Dataref Bridge is a **middleware application** that connects your custom hardware (Arduino, ESP32, joysticks, button boxes) to X-Plane flight simulator. 

Think of it like a **translator** between two people who speak different languages:
- **X-Plane** speaks "UDP packets with datarefs"
- **Your hardware** speaks "Serial commands" or "USB HID signals"
- **XPlane Dataref Bridge** translates between them!

### What Can You Do With It?

#### 🎮 **Inputs** (Hardware → X-Plane)
- Press a physical button → Toggle landing gear
- Turn an encoder knob → Adjust heading bug
- Move a throttle lever → Control engine power
- Flip a switch → Turn on landing lights

#### 💡 **Outputs** (X-Plane → Hardware)
- Gear status changes → LED turns on/off
- Airspeed value → Servo moves to position
- Warning triggered → Buzzer sounds
- Altitude display → 7-segment shows numbers

### Key Features

| Feature | Description |
|---------|-------------|
| **Conditional Logic** | "Only toggle gear if airspeed < 200 knots" |
| **Axis Calibration** | Deadzone, response curves, invert |
| **Sequences/Macros** | One button = multiple actions |
| **Universal Mapping** | One dataref broadcasts to ALL devices |
| **Profile System** | Save/load different configurations |
| **HID Support** | Works with joysticks via Windows API |
| **Hybrid Devices** | ESP32-S2/S3 as both input AND output |

---

## System Architecture

### The Big Picture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         YOUR COMPUTER                                │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                  XPlane Dataref Bridge                       │   │
│  │                                                               │   │
│  │  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐      │   │
│  │  │  HID Manager │    │Input Mapper │    │Arduino Mgr  │      │   │
│  │  │  (Joysticks) │    │ (Logic)     │    │ (Serial)    │      │   │
│  │  └──────┬──────┘    └──────┬──────┘    └──────┬──────┘      │   │
│  │         │                  │                   │              │   │
│  │         └──────────────────┼───────────────────┘              │   │
│  │                            │                                   │   │
│  │                    ┌───────┴───────┐                          │   │
│  │                    │ XPlane Conn   │                          │   │
│  │                    │ (UDP Socket)  │                          │   │
│  │                    └───────┬───────┘                          │   │
│  └────────────────────────────┼──────────────────────────────────┘   │
│                               │                                       │
└───────────────────────────────┼───────────────────────────────────────┘
                                │ UDP (Port 49000/49001)
                                ▼
                    ┌───────────────────────┐
                    │      X-PLANE 11/12    │
                    │                       │
                    │  Datarefs & Commands  │
                    └───────────────────────┘
```

### Data Flow Explained

#### Input Flow (Hardware → X-Plane)

```
Physical Button Press
        │
        ▼
┌───────────────────┐
│ HID Manager       │  Reads button state via Windows API
│ (or Arduino Mgr)  │  Generates: "BTN_3 pressed"
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ Input Mapper      │  Looks up mapping for BTN_3
│                   │  Checks conditions (if any)
│                   │  Decides action to take
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ XPlane Connection │  Sends UDP packet to X-Plane
│                   │  "Set sim/cockpit/gear = 1"
└─────────┬─────────┘
          │
          ▼
    X-Plane receives
    Gear goes down!
```

#### Output Flow (X-Plane → Hardware)

```
X-Plane gear changes
        │
        ▼
┌───────────────────┐
│ XPlane Connection │  Receives UDP packet
│                   │  "sim/cockpit/gear = 1"
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ Arduino Manager   │  Looks up Universal Mapping
│                   │  gear dataref → "GEAR" key
│                   │  Sends to ALL connected Arduinos
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ Arduino Device    │  Receives: "SET GEAR 1.0"
│                   │  Turns on LED!
└───────────────────┘
```

### Component Breakdown

| Component | File | Purpose |
|-----------|------|---------|
| **XPlaneConnection** | `core/xplane_connection.py` | UDP communication with X-Plane |
| **InputMapper** | `core/input_mapper.py` | Routes inputs to actions |
| **HIDManager** | `core/hid/hid_manager.py` | Reads joysticks/controllers |
| **ArduinoManager** | `core/arduino/arduino_manager.py` | Serial communication |
| **ProfileManager** | `core/profile_manager.py` | Save/load configurations |
| **DatarefManager** | `core/dataref_manager.py` | Dataref database & search |

---

## Installation

### Prerequisites

1. **Python 3.10+** - [Download here](https://python.org)
2. **X-Plane 11 or 12** - Must be running to send/receive data
3. **PyQt6** - For the graphical interface
4. **pyserial** - For Arduino communication

### Step-by-Step Installation

```bash
# 1. Clone or download the project
git clone https://github.com/yourusername/xplane-dataref-bridge.git
cd xplane-dataref-bridge

# 2. Create a virtual environment (recommended)
python -m venv venv

# 3. Activate the virtual environment
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# 4. Install dependencies
pip install PyQt6 pyserial qasync

# 5. Run the application
python main.py
```

### X-Plane Configuration

No special configuration needed! X-Plane automatically:
- **Listens** on UDP port **49000** (we send commands here)
- **Sends** on UDP port **49001** (we receive data here)

These are the default ports in X-Plane's networking settings.

---

## Quick Start Guide

### 5-Minute Setup: Button → Gear Toggle

Let's make a physical button toggle the landing gear!

#### Step 1: Connect Your Hardware

1. Plug in your joystick/controller OR Arduino with a button
2. Open XPlane Dataref Bridge
3. Go to **"Input Config"** tab

#### Step 2: Find Your Button

1. You'll see your controller in the left panel
2. Click on it to see all buttons/axes
3. Press your button - it should light up green!

#### Step 3: Configure the Mapping

1. Click the **⚙️** button next to your button
2. In the dialog:
   - **Action Type**: "Toggle On/Off (Button)"
   - **Target**: `sim/cockpit2/controls/gear_handle_down`
   - **Description**: "Gear Toggle"
3. Click **Save**

#### Step 4: Connect to X-Plane

1. Start X-Plane
2. In the app, click **"Connect to X-Plane"**
3. Status should turn green

#### Step 5: Test It!

Press your button - the gear should toggle in X-Plane!

---

## Core Concepts

### What is a Dataref?

A **dataref** is X-Plane's way of storing every piece of information about the simulation.

Think of datarefs like a **giant spreadsheet** where:
- Each row has a **name** (like `sim/cockpit/gear`)
- Each row has a **value** (like `1.0` for gear down)

Examples:
| Dataref | What It Means | Typical Values |
|---------|---------------|----------------|
| `sim/cockpit2/controls/gear_handle_down` | Gear handle position | 0 = up, 1 = down |
| `sim/cockpit2/engine/actuators/throttle_ratio_all` | Throttle position | 0.0 to 1.0 |
| `sim/cockpit2/gauges/indicators/airspeed_kts_pilot` | Indicated airspeed | 0 to 500+ |
| `sim/cockpit/autopilot/heading_mag` | Autopilot heading bug | 0 to 359 |

### What is a Command?

A **command** is an action in X-Plane - like clicking a button.

Unlike datarefs (which are values you can read/write), commands are **one-time actions**.

Examples:
| Command | What It Does |
|---------|--------------|
| `sim/flight_controls/landing_gear_toggle` | Toggle gear up/down |
| `sim/autopilot/heading_up` | Increase heading bug by 1° |
| `sim/lights/beacon_lights_toggle` | Toggle beacon light |

### Dataref vs Command: When to Use Which?

| Situation | Use This | Why |
|-----------|----------|-----|
| Toggle something | **Command** | X-Plane handles the toggle logic |
| Set exact value | **Dataref** | You control the exact value |
| Read a value | **Dataref** | Commands can't be read |
| Momentary action | **Command** | Just triggers once |
| Physical switch (on/off) | **Dataref** | Match switch position to value |

---

## Input Mapping

### Action Types Explained

#### 1. 🖱️ **Trigger Command**
Sends a one-time command when button is pressed.

**Best For:** Toggle switches, momentary buttons
```
Button Press → Send "sim/flight_controls/landing_gear_toggle"
```

#### 2. 🔘 **Set Exact Value**
Sets specific values on press and release.

**Best For:** Physical ON/OFF switches
```
Switch ON  → Set dataref to 1.0
Switch OFF → Set dataref to 0.0
```

#### 3. 🔄 **Toggle On/Off**
Flips between 0 and 1 each press.

**Best For:** Momentary buttons controlling toggles
```
Press 1 → Value becomes 1
Press 2 → Value becomes 0
Press 3 → Value becomes 1
```

#### 4. ⬆️ **Increase Value**
Adds to the current value.

**Best For:** Encoder clockwise, "+" buttons
```
Current: 180° → Press → New: 181°
```

#### 5. ⬇️ **Decrease Value**
Subtracts from the current value.

**Best For:** Encoder counter-clockwise, "-" buttons
```
Current: 180° → Press → New: 179°
```

#### 6. 📊 **Axis**
Maps analog input to dataref range.

**Best For:** Throttle, mixture, prop, flight controls
```
Lever at 50% → Throttle = 0.5
```

#### 7. 📜 **Sequence**
Multiple actions from one button.

**Best For:** Checklists, complex procedures
```
One Press → Flaps 15° → Gear Down → Lights On
```

---

## Output Mapping

### Universal Keys

Instead of mapping datarefs directly to specific devices, we use **Universal Keys**.

**How it works:**
1. Assign a **Key** to a dataref (e.g., `sim/cockpit/gear` → `GEAR`)
2. ALL connected Arduinos receive: `SET GEAR 1.0`
3. Each Arduino decides what to do with `GEAR`

**Why Universal Keys?**
- Swap Arduinos without reconfiguring
- Multiple Arduinos can react to same data
- Cleaner firmware code

### Setting Up Outputs

1. Go to **"Output Config"** tab
2. Search for a dataref (e.g., "gear")
3. Click **Subscribe**
4. Enter a **Key** (e.g., "GEAR")
5. Connected Arduinos now receive gear updates!

---

## Conditional Logic

### What Are Conditions?

Conditions let you **restrict when an action can execute**.

**Real Example:** Don't allow gear toggle above 200 knots (prevents gear damage!)

### Setting Up a Condition

1. Open input mapping dialog
2. Expand **"3. Conditions"** section
3. Enable **"Enable conditional execution"**
4. Configure:
   - **Check Dataref:** `sim/cockpit2/gauges/indicators/airspeed_kts_pilot`
   - **Condition:** `<` (less than)
   - **Value:** `200`

Now the gear will only toggle if airspeed is below 200 knots!

### Available Operators

| Operator | Meaning | Example |
|----------|---------|---------|
| `<` | Less than | Airspeed < 200 |
| `<=` | Less than or equal | Altitude <= 10000 |
| `>` | Greater than | RPM > 1000 |
| `>=` | Greater than or equal | Fuel >= 0.1 |
| `==` | Equal to | Gear == 1 (down) |
| `!=` | Not equal to | Engine != 0 (running) |

### Common Condition Examples

| Action | Condition | Why |
|--------|-----------|-----|
| Toggle Gear | Airspeed < 200 kts | Prevent gear damage |
| Extend Flaps | Airspeed < 180 kts | Prevent flap damage |
| Start Engine | Fuel > 0 | Can't start without fuel |
| Engage AP | Altitude > 1000 ft | Minimum engagement altitude |

---

## Axis Calibration

### Understanding Axes

An **axis** is an analog input that sends a range of values (not just on/off).

Examples: Throttle lever, joystick, potentiometer, slider

### The Calibration Pipeline

```
Raw Hardware Input
        │
        ▼
┌───────────────────┐
│ 1. Input Range    │  Clamp to min/max
│    (-1.0 to 1.0)  │
└─────────┬─────────┘
        │
        ▼
┌───────────────────┐
│ 2. Deadzone       │  Ignore small movements
│                   │
└─────────┬─────────┘
        │
        ▼
┌───────────────────┐
│ 3. Response Curve │  Adjust sensitivity
│                   │
└─────────┬─────────┘
        │
        ▼
┌───────────────────┐
│ 4. Invert         │  Reverse if needed
│                   │
└─────────┬─────────┘
        │
        ▼
┌───────────────────┐
│ 5. Output Range   │  Map to dataref range
│    (0.0 to 1.0)   │
└───────────────────┘
```

### Deadzone Positions

#### 🎯 **Center Deadzone**
Ignores small movements around the center position.

**Best For:** Joysticks, yokes, rudder pedals

```
        Deadzone
           ││
    ───────██───────
    -1     0      +1
           ▲
      Center ignored
```

#### ⬅️ **Left/Bottom Deadzone**
Ignores values near the minimum.

**Best For:** Throttle idle cutoff, mixture lean stop

```
    Deadzone
    ████───────────
    -1             +1
    ▲
 Minimum ignored
```

#### ➡️ **Right/Top Deadzone**
Ignores values near the maximum.

**Best For:** Full throttle detent, full brake

```
           Deadzone
    ───────────████
    -1             +1
                   ▲
            Maximum ignored
```

#### ↔️ **Both Ends Deadzone**
Ignores values at both extremes.

**Best For:** Worn potentiometers with noisy ends

```
    DZ           DZ
    ██─────────────██
    -1             +1
    ▲               ▲
  Both ends ignored
```

### Response Curves

#### 📏 **Linear**
Direct 1:1 response. Input equals output.

**Best For:** When you want exact control

#### ⚡ **Aggressive (√x)**
More sensitive near center, less at extremes.

**Best For:** Flight controls needing precise small adjustments

#### 🪶 **Soft (x²)**
Less sensitive near center, more at extremes.

**Best For:** Large aircraft, avoiding over-correction

#### 🌊 **Smooth (x^1.5)**
Gentle acceleration curve.

**Best For:** General purpose, balanced feel

#### 🎯 **Ultra Fine (x³)**
Maximum precision near center.

**Best For:** Helicopter hover, precise formation flying

#### 〰️ **S-Curve**
Smooth start and end with faster middle.

**Best For:** Natural feeling movement

#### 📈 **Exponential**
Slow start, fast finish.

**Best For:** Throttle/brake feel

---

## Sequences & Macros

### What Are Sequences?

A **sequence** lets you trigger **multiple actions** with a **single button press**.

### Example: Landing Configuration

One button press does:
1. Set Flaps to 15°
2. Wait 500ms
3. Lower Landing Gear
4. Turn on Landing Lights
5. Arm Speedbrakes

### Sequence Options

#### ⏹️ **Stop on Error**
If any step fails (condition not met), stop the whole sequence.

#### 🔄 **Repeat While Held**
Keep executing the sequence as long as button is held.

#### ↩️ **Reverse on Release**
When button released, undo everything in reverse order.

### Creating a Sequence

1. Select **"Sequence (Multiple Actions)"** as action type
2. Click **"Add Command"** or **"Add Dataref"** to add steps
3. Set delay (ms) between steps
4. Drag to reorder
5. Configure behavior options

---

## Arduino/ESP32 Integration

See the separate Arduino documentation files:
- [Basic Communication Protocol](arduino/PROTOCOL.md)
- [Input Sketches](arduino/inputs/)
- [Output Sketches](arduino/outputs/)
- [Hybrid Examples](arduino/hybrid/)

---

## Troubleshooting

### X-Plane Won't Connect

1. **Is X-Plane running?** Must be running first
2. **Check IP address:** Should be `127.0.0.1` for same computer
3. **Check ports:** Default is 49000 (send) and 49001 (receive)
4. **Firewall:** May need to allow the app through firewall

### Arduino Not Detected

1. **Check USB connection**
2. **Install drivers** (CH340 for cheap Arduinos, CP2102 for ESP32)
3. **Check COM port** in Device Manager
4. **Baud rate** must match (default: 115200)

### Buttons/Axes Not Working

1. **Check Input Config tab** - can you see the input change?
2. **Check mapping exists** - is there a mapping for this input?
3. **Check condition** - is a condition blocking execution?
4. **Check X-Plane connection** - must be connected

### Values Not Updating

1. **Subscribe to dataref** in Output Config tab
2. **Check Universal Key** is set
3. **Check Arduino firmware** handles the key

---

## Support & Contributing

### Getting Help

1. Check this documentation
2. Look at example sketches
3. Open an issue on GitHub

### Contributing

Pull requests welcome! Please:
1. Follow existing code style
2. Add comments explaining changes
3. Test with actual hardware if possible

---

*Documentation Version: 2.0*
*Last Updated: 2024*
