from __future__ import annotations
import logging
import asyncio
import math
from typing import Dict, List, Callable, Optional, Any
from dataclasses import dataclass, field
from enum import Enum, auto
import json
from pathlib import Path

log = logging.getLogger(__name__)


class InputAction(Enum):
    """Type of action to perform when input is received."""
    COMMAND = auto()        # Send X-Plane command
    DATAREF_SET = auto()    # Set dataref to specific value
    DATAREF_TOGGLE = auto() # Toggle dataref between 0 and 1
    DATAREF_INC = auto()    # Increment dataref
    DATAREF_DEC = auto()    # Decrement dataref
    AXIS = auto()           # Map axis value to dataref
    SEQUENCE = auto()       # Execute multiple actions in sequence
    CUSTOM = auto()         # Custom callback


class DeadzonePosition(Enum):
    """Where the deadzone is applied on the axis."""
    CENTER = "center"       # Deadzone around center (for joysticks/yokes)
    LEFT = "left"           # Deadzone at minimum (for throttle idle cutoff)
    RIGHT = "right"         # Deadzone at maximum (for throttle max detent)
    ENDS = "ends"           # Deadzone at both ends (for worn potentiometers)


class ResponseCurve(Enum):
    """Response curve type for axis mapping."""
    LINEAR = "linear"       # Direct 1:1 response
    SMOOTH = "smooth"       # Gentle acceleration (x^1.5)
    AGGRESSIVE = "aggressive"  # Quick response, fine center control (√x)
    SOFT = "soft"           # Precise center, fast at extremes (x²)
    ULTRA_FINE = "ultra_fine"  # Maximum precision center (x³)
    S_CURVE = "s_curve"     # Smooth start and end (smoothstep)
    EXPONENTIAL = "exponential"  # Slow start, fast finish


@dataclass
class SequenceAction:
    """A single action within a sequence."""
    action_type: str        # "command" or "dataref"
    target: str             # Command or dataref name
    value: float = 0.0      # Value to set (for dataref)
    delay_ms: int = 0       # Delay after this action (milliseconds)
    
    def to_dict(self) -> Dict:
        return {
            "action_type": self.action_type,
            "target": self.target,
            "value": self.value,
            "delay_ms": self.delay_ms,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "SequenceAction":
        return cls(
            action_type=data.get("action_type", "command"),
            target=data.get("target", ""),
            value=data.get("value", 0.0),
            delay_ms=data.get("delay_ms", 0),
        )


@dataclass
class InputMapping:
    """Defines how an input maps to an X-Plane action."""
    
    input_key: str              # e.g., "BTN_AP", "ENC_HDG", "AXIS_0"
    device_port: str            # e.g., "COM3", "WINMM_0", or "*" for all devices
    
    action: InputAction
    target: str                 # Command or dataref name
    
    # For DATAREF_SET
    value_on: float = 1.0
    value_off: float = 0.0
    
    # For DATAREF_INC/DEC/AXIS
    increment: float = 1.0
    min_value: float = 0.0      # Target Min (for Axis: Output Min)
    max_value: float = 360.0    # Target Max (for Axis: Output Max)
    wrap: bool = False          # Wrap around at min/max
    
    # For AXIS Calibration
    axis_min: float = -1.0      # Raw Input Min (normalized from HID)
    axis_max: float = 1.0       # Raw Input Max (normalized from HID)
    axis_deadzone: float = 0.0  # Deadzone size (0.0 - 0.5)
    axis_deadzone_pos: str = "center"  # Deadzone position: center, left, right, ends
    axis_curve: str = "linear"  # Response curve: linear, smooth, aggressive, soft
    axis_invert: bool = False   # Invert axis direction
    
    # For encoders
    multiplier: float = 1.0     # Multiply encoder delta by this
    
    # === NEW: Condition Fields ===
    condition_enabled: bool = False
    condition_dataref: str = ""         # Dataref to check
    condition_operator: str = "<"       # <, <=, >, >=, ==, !=
    condition_value: float = 0.0        # Value to compare against
    
    # === NEW: Sequence Fields ===
    sequence_actions: List[SequenceAction] = field(default_factory=list)
    sequence_stop_on_error: bool = False    # Stop sequence if condition fails
    sequence_repeat_while_held: bool = False  # Repeat while button held
    sequence_reverse_on_release: bool = False  # Reverse sequence on release
    
    # Metadata
    description: str = ""
    enabled: bool = True
    
    def to_dict(self) -> Dict:
        return {
            "input_key": self.input_key,
            "device_port": self.device_port,
            "action": self.action.name,
            "target": self.target,
            "value_on": self.value_on,
            "value_off": self.value_off,
            "increment": self.increment,
            "min_value": self.min_value,
            "max_value": self.max_value,
            "wrap": self.wrap,
            "axis_min": self.axis_min,
            "axis_max": self.axis_max,
            "axis_deadzone": self.axis_deadzone,
            "axis_deadzone_pos": self.axis_deadzone_pos,
            "axis_curve": self.axis_curve,
            "axis_invert": self.axis_invert,
            "multiplier": self.multiplier,
            # Condition fields
            "condition_enabled": self.condition_enabled,
            "condition_dataref": self.condition_dataref,
            "condition_operator": self.condition_operator,
            "condition_value": self.condition_value,
            # Sequence fields
            "sequence_actions": [a.to_dict() for a in self.sequence_actions],
            "sequence_stop_on_error": self.sequence_stop_on_error,
            "sequence_repeat_while_held": self.sequence_repeat_while_held,
            "sequence_reverse_on_release": self.sequence_reverse_on_release,
            # Metadata
            "description": self.description,
            "enabled": self.enabled,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "InputMapping":
        # Parse sequence actions
        seq_actions = []
        for action_data in data.get("sequence_actions", []):
            seq_actions.append(SequenceAction.from_dict(action_data))
        
        return cls(
            input_key=data["input_key"],
            device_port=data.get("device_port", "*"),
            action=InputAction[data["action"]],
            target=data["target"],
            value_on=data.get("value_on", 1.0),
            value_off=data.get("value_off", 0.0),
            increment=data.get("increment", 1.0),
            min_value=data.get("min_value", 0.0),
            max_value=data.get("max_value", 360.0),
            wrap=data.get("wrap", False),
            axis_min=data.get("axis_min", -1.0),
            axis_max=data.get("axis_max", 1.0),
            axis_deadzone=data.get("axis_deadzone", 0.0),
            axis_deadzone_pos=data.get("axis_deadzone_pos", "center"),
            axis_curve=data.get("axis_curve", "linear"),
            axis_invert=data.get("axis_invert", False),
            multiplier=data.get("multiplier", 1.0),
            # Condition fields
            condition_enabled=data.get("condition_enabled", False),
            condition_dataref=data.get("condition_dataref", ""),
            condition_operator=data.get("condition_operator", "<"),
            condition_value=data.get("condition_value", 0.0),
            # Sequence fields
            sequence_actions=seq_actions,
            sequence_stop_on_error=data.get("sequence_stop_on_error", False),
            sequence_repeat_while_held=data.get("sequence_repeat_while_held", False),
            sequence_reverse_on_release=data.get("sequence_reverse_on_release", False),
            # Metadata
            description=data.get("description", ""),
            enabled=data.get("enabled", True),
        )


class InputMapper:
    """
    Maps device inputs to X-Plane actions.
    
    Supports:
    - Conditional execution (check dataref before acting)
    - Axis calibration with deadzone and response curves
    - Sequence macros (multiple actions per input)
    """
    
    MAPPINGS_FILE = Path(__file__).parent.parent / "config" / "input_mappings.json"
    
    def __init__(self, xplane_connection, dataref_manager=None) -> None:
        self.xplane_conn = xplane_connection
        self.dataref_manager = dataref_manager

        self._mappings: List[InputMapping] = []
        self._current_values: Dict[str, float] = {}  # dataref -> current value
        
        # Track active sequences for repeat-while-held
        self._active_sequences: Dict[str, asyncio.Task] = {}

        # Callbacks
        self.on_mapping_triggered: Optional[Callable[[InputMapping, float], None]] = None
        self.on_condition_failed: Optional[Callable[[InputMapping, str], None]] = None

        self._load_mappings()
        self._create_default_mappings()
    
    def _load_mappings(self) -> None:
        """Load mappings from file."""
        # Legacy loading disabled in favor of ProfileManager
        pass
    
    def _create_default_mappings(self) -> None:
        """Create default mappings if none exist."""
        # Default creation disabled in favor of ProfileManager
        pass
    
    def save_mappings(self) -> bool:
        """Save mappings to file."""
        # Legacy saving disabled in favor of ProfileManager
        return True
    
    def add_mapping(self, mapping: InputMapping) -> None:
        """Add a new mapping."""
        self._mappings.append(mapping)
    
    def remove_mapping(self, index: int) -> None:
        """Remove a mapping by index."""
        if 0 <= index < len(self._mappings):
            del self._mappings[index]
    
    def get_mappings(self) -> List[InputMapping]:
        """Get all mappings."""
        return self._mappings.copy()
    
    def get_mappings_for_input(self, input_key: str, device_port: str = None) -> List[InputMapping]:
        """Get all mappings for a specific input."""
        result = []
        for m in self._mappings:
            if not m.enabled:
                continue
            if m.input_key != input_key:
                continue
            if m.device_port != "*" and device_port and m.device_port != device_port:
                continue
            result.append(m)
        return result

    def remove_mappings_for_input(self, input_key: str, device_port: str) -> None:
        """Remove all mappings matching key and device."""
        initial_len = len(self._mappings)
        self._mappings = [m for m in self._mappings
                          if not (m.input_key == input_key and m.device_port == device_port)]

        if len(self._mappings) < initial_len:
            log.info("Removed %d old mapping(s) for %s on %s", 
                     initial_len - len(self._mappings), input_key, device_port)

    def update_current_value(self, dataref: str, value: float) -> None:
        """Update tracked current value for a dataref."""
        self._current_values[dataref] = value
    
    def get_current_value(self, dataref: str) -> Optional[float]:
        """Get the current tracked value for a dataref."""
        return self._current_values.get(dataref)
    
    # =========================================================================
    # Condition Evaluation
    # =========================================================================
    
    def _check_condition(self, mapping: InputMapping) -> tuple[bool, str]:
        """
        Evaluate if condition is met before executing.
        
        Returns:
            (condition_met, reason_string)
        """
        if not mapping.condition_enabled:
            return True, ""  # No condition = always execute
        
        if not mapping.condition_dataref:
            return True, "No condition dataref specified"
        
        current = self._current_values.get(mapping.condition_dataref)
        
        if current is None:
            # Dataref not tracked yet - this might be an issue
            log.warning("Condition dataref not tracked: %s", mapping.condition_dataref)
            return False, f"Dataref '{mapping.condition_dataref}' has no value (not subscribed?)"
        
        target = mapping.condition_value
        op = mapping.condition_operator
        
        # Evaluate condition
        operators = {
            "<": lambda a, b: a < b,
            "<=": lambda a, b: a <= b,
            ">": lambda a, b: a > b,
            ">=": lambda a, b: a >= b,
            "==": lambda a, b: abs(a - b) < 0.001,  # Float comparison with tolerance
            "!=": lambda a, b: abs(a - b) >= 0.001,
        }
        
        eval_func = operators.get(op)
        if not eval_func:
            log.error("Unknown condition operator: %s", op)
            return False, f"Unknown operator: {op}"
        
        result = eval_func(current, target)
        
        if result:
            reason = f"Condition MET: {mapping.condition_dataref} ({current:.2f}) {op} {target:.2f}"
        else:
            reason = f"Condition NOT MET: {mapping.condition_dataref} ({current:.2f}) {op} {target:.2f}"
        
        log.debug(reason)
        
        return result, reason
    
    # =========================================================================
    # Axis Processing with Deadzone and Curves
    # =========================================================================
    
    def _apply_axis_processing(self, raw_value: float, mapping: InputMapping) -> float:
        """
        Apply deadzone, response curve, and output mapping to axis input.
        
        Args:
            raw_value: Raw normalized input (-1.0 to 1.0 from HID)
            mapping: The axis mapping configuration
            
        Returns:
            Processed output value mapped to target range
        """
        # 1. Clamp to configured input range
        value = max(mapping.axis_min, min(mapping.axis_max, raw_value))
        
        # 2. Normalize to -1.0 to 1.0 based on configured range
        if mapping.axis_max != mapping.axis_min:
            # For center-based: normalize to -1..1
            # For end-based: normalize to 0..1
            input_range = mapping.axis_max - mapping.axis_min
            normalized = (value - mapping.axis_min) / input_range * 2.0 - 1.0
        else:
            normalized = 0.0
        
        # 3. Apply deadzone based on position
        dz = mapping.axis_deadzone
        dz_pos = mapping.axis_deadzone_pos
        
        if dz > 0:
            normalized = self._apply_deadzone(normalized, dz, dz_pos)
        
        # 4. Apply response curve
        curve = mapping.axis_curve
        normalized = self._apply_curve(normalized, curve)
        
        # 5. Invert if needed
        if mapping.axis_invert:
            normalized = -normalized
        
        # 6. Map to output range (min_value to max_value)
        # Convert from -1..1 to 0..1 first
        output_normalized = (normalized + 1.0) / 2.0
        
        # Then map to output range
        output_value = mapping.min_value + (output_normalized * (mapping.max_value - mapping.min_value))
        
        return output_value
    
    def _apply_deadzone(self, value: float, deadzone: float, position: str) -> float:
        """
        Apply deadzone based on position setting.
        
        Args:
            value: Normalized input (-1.0 to 1.0)
            deadzone: Deadzone size (0.0 to 0.5)
            position: 'center', 'left', 'right', or 'ends'
            
        Returns:
            Value with deadzone applied
        """
        if position == "center":
            # Deadzone around center - common for joysticks/yokes
            if abs(value) < deadzone:
                return 0.0
            else:
                # Scale remaining range to full output
                sign = 1.0 if value > 0 else -1.0
                return sign * (abs(value) - deadzone) / (1.0 - deadzone)
        
        elif position == "left":
            # Deadzone at minimum (left/bottom)
            # Convert to 0..1 range for easier processing
            val_01 = (value + 1.0) / 2.0  # -1..1 -> 0..1
            dz_01 = deadzone  # Deadzone as fraction of full range
            
            if val_01 < dz_01:
                return -1.0  # Output minimum
            else:
                # Scale remaining range
                scaled = (val_01 - dz_01) / (1.0 - dz_01)
                return scaled * 2.0 - 1.0  # Back to -1..1
        
        elif position == "right":
            # Deadzone at maximum (right/top)
            val_01 = (value + 1.0) / 2.0  # -1..1 -> 0..1
            dz_01 = deadzone
            
            if val_01 > (1.0 - dz_01):
                return 1.0  # Output maximum
            else:
                # Scale remaining range
                scaled = val_01 / (1.0 - dz_01)
                return scaled * 2.0 - 1.0  # Back to -1..1
        
        elif position == "ends":
            # Deadzone at both ends
            val_01 = (value + 1.0) / 2.0  # -1..1 -> 0..1
            dz_half = deadzone / 2.0  # Split deadzone between both ends
            
            if val_01 < dz_half:
                return -1.0  # Output minimum
            elif val_01 > (1.0 - dz_half):
                return 1.0  # Output maximum
            else:
                # Scale middle range to full output
                scaled = (val_01 - dz_half) / (1.0 - deadzone)
                return scaled * 2.0 - 1.0  # Back to -1..1
        
        return value  # Fallback
    
    def _apply_curve(self, value: float, curve: str) -> float:
        """
        Apply response curve to normalized value.
        
        Args:
            value: Normalized input (-1.0 to 1.0)
            curve: Curve type ('linear', 'smooth', 'aggressive', 'soft', 'ultra_fine', 's_curve', 'exponential')
            
        Returns:
            Curved value (-1.0 to 1.0)
        """
        sign = 1.0 if value >= 0 else -1.0
        abs_val = abs(value)
        
        if curve == "linear":
            return value
        
        elif curve == "aggressive":
            # Square root - more sensitive near center, less at extremes
            # Good for precise control with quick authority
            return sign * math.pow(abs_val, 0.5)
        
        elif curve == "soft":
            # Squared - less sensitive near center, more at extremes
            # Good for large aircraft needing fine adjustments
            return sign * math.pow(abs_val, 2.0)
        
        elif curve == "smooth":
            # x^1.5 - gentle acceleration
            # Good balance for general use
            return sign * math.pow(abs_val, 1.5)
        
        elif curve == "ultra_fine":
            # Cubic - maximum precision near center
            # For when you need very fine adjustments
            return sign * math.pow(abs_val, 3.0)
        
        elif curve == "s_curve":
            # Smoothstep function - eases in and out
            # Natural feeling movement
            t = abs_val
            return sign * (t * t * (3.0 - 2.0 * t))
        
        elif curve == "exponential":
            # Exponential - slow start, fast finish
            # Good for throttle/brake feel
            return sign * ((math.exp(abs_val) - 1) / (math.e - 1))
        
        return value  # Fallback
    
    # =========================================================================
    # Input Processing
    # =========================================================================
    
    async def process_input(self, device_port: str, input_key: str, value: float) -> None:
        """
        Process an input from a device.
        
        Args:
            device_port: The device ID (e.g., "COM3", "WINMM_0")
            input_key: The input identifier (e.g., "BTN_3", "AXIS_0")
            value: The input value (1/0 for buttons, -1..1 for axes)
        """
        mappings = self.get_mappings_for_input(input_key, device_port)
        
        if not mappings:
            log.debug("No mapping for input: %s from %s", input_key, device_port)
            return
        
        for mapping in mappings:
            await self._execute_mapping(mapping, value)
    
    async def _execute_mapping(self, mapping: InputMapping, value: float) -> None:
        """Execute a mapping action."""
        
        if not self.xplane_conn or not self.xplane_conn.connected:
            log.warning("Cannot execute mapping: X-Plane not connected")
            return
        
        # Check condition first (except for AXIS which should always process)
        if mapping.action != InputAction.AXIS:
            condition_met, reason = self._check_condition(mapping)
            if not condition_met:
                log.info("Action blocked: %s", reason)
                if self.on_condition_failed:
                    self.on_condition_failed(mapping, reason)
                return
        
        try:
            if mapping.action == InputAction.COMMAND:
                await self._execute_command(mapping, value)
            
            elif mapping.action == InputAction.DATAREF_SET:
                await self._execute_dataref_set(mapping, value)
            
            elif mapping.action == InputAction.DATAREF_TOGGLE:
                await self._execute_dataref_toggle(mapping, value)
            
            elif mapping.action == InputAction.DATAREF_INC:
                await self._execute_dataref_inc(mapping, value, 1)
            
            elif mapping.action == InputAction.DATAREF_DEC:
                await self._execute_dataref_inc(mapping, value, -1)
            
            elif mapping.action == InputAction.AXIS:
                await self._execute_axis(mapping, value)
            
            elif mapping.action == InputAction.SEQUENCE:
                await self._execute_sequence(mapping, value)
            
            # Notify listeners
            if self.on_mapping_triggered:
                self.on_mapping_triggered(mapping, value)
                
        except Exception as e:
            log.error("Failed to execute mapping: %s", e)
    
    async def _execute_command(self, mapping: InputMapping, value: float) -> None:
        """Execute a command action."""
        # Only send command on button press (value > 0)
        if value > 0:
            await self.xplane_conn.send_command(mapping.target)
            log.info("Sent command: %s", mapping.target)
    
    async def _execute_dataref_set(self, mapping: InputMapping, value: float) -> None:
        """Execute a set-value action."""
        # Set to value_on on press, value_off on release
        new_value = mapping.value_on if value > 0 else mapping.value_off
        await self.xplane_conn.write_dataref(mapping.target, new_value)
        log.info("Set dataref: %s = %.2f", mapping.target, new_value)
    
    async def _execute_dataref_toggle(self, mapping: InputMapping, value: float) -> None:
        """Execute a toggle action."""
        # Toggle between 0 and 1 on press only
        if value > 0:
            current = self._current_values.get(mapping.target, 0)
            new_value = 0.0 if current > 0.5 else 1.0
            await self.xplane_conn.write_dataref(mapping.target, new_value)
            self._current_values[mapping.target] = new_value
            log.info("Toggled dataref: %s = %.2f", mapping.target, new_value)
    
    async def _execute_dataref_inc(self, mapping: InputMapping, value: float, direction: int) -> None:
        """Execute an increment/decrement action."""
        current = self._current_values.get(mapping.target, 0)
        delta = value * mapping.increment * mapping.multiplier * direction
        new_value = current + delta
        
        # Apply limits
        if mapping.wrap:
            value_range = mapping.max_value - mapping.min_value
            if new_value > mapping.max_value:
                new_value = mapping.min_value + (new_value - mapping.max_value) % value_range
            elif new_value < mapping.min_value:
                new_value = mapping.max_value - (mapping.min_value - new_value) % value_range
        else:
            new_value = max(mapping.min_value, min(mapping.max_value, new_value))
        
        await self.xplane_conn.write_dataref(mapping.target, new_value)
        self._current_values[mapping.target] = new_value
        log.info("Incremented dataref: %s = %.2f (delta: %.2f)", 
                mapping.target, new_value, delta)
    
    async def _execute_axis(self, mapping: InputMapping, value: float) -> None:
        """Execute an axis mapping."""
        # Process the axis value through calibration, deadzone, and curve
        output_value = self._apply_axis_processing(value, mapping)
        
        # Only send if changed significantly to avoid spam
        current = self._current_values.get(mapping.target, -999999)
        if abs(output_value - current) > 0.001:
            await self.xplane_conn.write_dataref(mapping.target, output_value)
            self._current_values[mapping.target] = output_value
            # log.debug("Axis %s -> %s = %.3f", mapping.input_key, mapping.target, output_value)
    
    async def _execute_sequence(self, mapping: InputMapping, value: float) -> None:
        """Execute a sequence of actions."""
        seq_key = f"{mapping.device_port}:{mapping.input_key}"
        
        if value > 0:
            # Button pressed - start sequence
            if seq_key in self._active_sequences:
                # Cancel any existing sequence for this input
                self._active_sequences[seq_key].cancel()
            
            # Start new sequence
            task = asyncio.create_task(
                self._run_sequence(mapping, seq_key)
            )
            self._active_sequences[seq_key] = task
        
        else:
            # Button released
            if seq_key in self._active_sequences:
                # Cancel repeat-while-held if active
                if mapping.sequence_repeat_while_held:
                    self._active_sequences[seq_key].cancel()
                    del self._active_sequences[seq_key]
                
                # Execute reverse sequence if enabled
                if mapping.sequence_reverse_on_release:
                    await self._run_sequence_reverse(mapping)
    
    async def _run_sequence(self, mapping: InputMapping, seq_key: str) -> None:
        """Run a sequence of actions."""
        try:
            while True:  # Loop for repeat-while-held
                for i, action in enumerate(mapping.sequence_actions):
                    # Check condition before each step if stop-on-error is enabled
                    if mapping.sequence_stop_on_error:
                        condition_met, reason = self._check_condition(mapping)
                        if not condition_met:
                            log.info("Sequence aborted at step %d: %s", i + 1, reason)
                            return
                    
                    # Execute the action
                    await self._execute_sequence_action(action, i + 1)
                    
                    # Wait for delay before next action
                    if action.delay_ms > 0:
                        await asyncio.sleep(action.delay_ms / 1000.0)
                
                log.info("Sequence completed: %d actions", len(mapping.sequence_actions))
                
                # Only repeat if configured
                if not mapping.sequence_repeat_while_held:
                    break
                
                # Small delay between repeats
                await asyncio.sleep(0.05)
        
        except asyncio.CancelledError:
            log.debug("Sequence cancelled")
        
        finally:
            # Clean up
            if seq_key in self._active_sequences:
                del self._active_sequences[seq_key]
    
    async def _run_sequence_reverse(self, mapping: InputMapping) -> None:
        """Run sequence in reverse order with opposite values."""
        for i, action in enumerate(reversed(mapping.sequence_actions)):
            # Create reversed action (invert value for datarefs)
            if action.action_type == "dataref":
                # Simple toggle logic: 1 -> 0, 0 -> 1
                reversed_value = 0.0 if action.value > 0.5 else 1.0
                reversed_action = SequenceAction(
                    action_type=action.action_type,
                    target=action.target,
                    value=reversed_value,
                    delay_ms=action.delay_ms
                )
            else:
                # Commands don't have a reverse
                reversed_action = action
            
            await self._execute_sequence_action(reversed_action, i + 1)
            
            if reversed_action.delay_ms > 0:
                await asyncio.sleep(reversed_action.delay_ms / 1000.0)
    
    async def _execute_sequence_action(self, action: SequenceAction, step_num: int) -> None:
        """Execute a single sequence action."""
        try:
            if action.action_type == "command":
                await self.xplane_conn.send_command(action.target)
                log.info("Sequence step %d: CMD %s", step_num, action.target)
            else:
                await self.xplane_conn.write_dataref(action.target, action.value)
                self._current_values[action.target] = action.value
                log.info("Sequence step %d: DREF %s = %.2f", step_num, action.target, action.value)
        
        except Exception as e:
            log.error("Sequence step %d failed: %s", step_num, e)
