"""
Unit tests for the InputMapper class.
Tests conditional logic, axis processing, and sequence execution.
"""
import pytest
import asyncio
import math
from unittest.mock import MagicMock, AsyncMock, patch

# Add parent directory to path for imports
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.input_mapper import (
    InputMapper, InputMapping, InputAction, SequenceAction,
    DeadzonePosition, ResponseCurve
)


class MockXPlaneConnection:
    """Mock X-Plane connection for testing."""
    
    def __init__(self):
        self.connected = True
        self.written_datarefs = []
        self.sent_commands = []
    
    async def write_dataref(self, dataref: str, value: float) -> bool:
        self.written_datarefs.append((dataref, value))
        return True
    
    async def send_command(self, command: str) -> bool:
        self.sent_commands.append(command)
        return True


class TestConditionEvaluation:
    """Tests for conditional logic evaluation."""
    
    @pytest.fixture
    def mapper(self):
        """Create an InputMapper with mock connection."""
        mock_conn = MockXPlaneConnection()
        mapper = InputMapper(mock_conn)
        return mapper
    
    def test_condition_disabled_always_passes(self, mapper):
        """When condition is disabled, should always return True."""
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=False,
            condition_dataref="sim/test/value",
            condition_operator="<",
            condition_value=100.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is True
    
    def test_condition_less_than_met(self, mapper):
        """Test < operator when condition is met."""
        mapper.update_current_value("sim/test/airspeed", 150.0)
        
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=True,
            condition_dataref="sim/test/airspeed",
            condition_operator="<",
            condition_value=200.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is True
        assert "MET" in reason
    
    def test_condition_less_than_not_met(self, mapper):
        """Test < operator when condition is NOT met."""
        mapper.update_current_value("sim/test/airspeed", 250.0)
        
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=True,
            condition_dataref="sim/test/airspeed",
            condition_operator="<",
            condition_value=200.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is False
        assert "NOT MET" in reason
    
    def test_condition_greater_than(self, mapper):
        """Test > operator."""
        mapper.update_current_value("sim/test/altitude", 5000.0)
        
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=True,
            condition_dataref="sim/test/altitude",
            condition_operator=">",
            condition_value=3000.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is True
    
    def test_condition_equal(self, mapper):
        """Test == operator with float tolerance."""
        mapper.update_current_value("sim/test/gear", 1.0)
        
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=True,
            condition_dataref="sim/test/gear",
            condition_operator="==",
            condition_value=1.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is True
    
    def test_condition_not_equal(self, mapper):
        """Test != operator."""
        mapper.update_current_value("sim/test/gear", 0.0)
        
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=True,
            condition_dataref="sim/test/gear",
            condition_operator="!=",
            condition_value=1.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is True
    
    def test_condition_less_than_or_equal(self, mapper):
        """Test <= operator at boundary."""
        mapper.update_current_value("sim/test/speed", 200.0)
        
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=True,
            condition_dataref="sim/test/speed",
            condition_operator="<=",
            condition_value=200.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is True
    
    def test_condition_dataref_not_tracked(self, mapper):
        """Test when condition dataref has no value."""
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command",
            condition_enabled=True,
            condition_dataref="sim/test/unknown",
            condition_operator="<",
            condition_value=100.0
        )
        
        result, reason = mapper._check_condition(mapping)
        assert result is False
        assert "no value" in reason.lower()


class TestDeadzoneProcessing:
    """Tests for deadzone application."""
    
    @pytest.fixture
    def mapper(self):
        mock_conn = MockXPlaneConnection()
        return InputMapper(mock_conn)
    
    def test_center_deadzone_in_zone(self, mapper):
        """Value within center deadzone should return 0."""
        result = mapper._apply_deadzone(0.03, 0.05, "center")
        assert result == 0.0
    
    def test_center_deadzone_outside_positive(self, mapper):
        """Value outside center deadzone should be scaled."""
        result = mapper._apply_deadzone(0.5, 0.1, "center")
        # Expected: (0.5 - 0.1) / (1.0 - 0.1) = 0.4 / 0.9 ≈ 0.444
        assert 0.44 < result < 0.45
    
    def test_center_deadzone_outside_negative(self, mapper):
        """Negative value outside center deadzone."""
        result = mapper._apply_deadzone(-0.5, 0.1, "center")
        assert -0.45 < result < -0.44
    
    def test_left_deadzone_in_zone(self, mapper):
        """Value within left deadzone should return -1."""
        result = mapper._apply_deadzone(-0.95, 0.1, "left")
        assert result == -1.0
    
    def test_left_deadzone_outside(self, mapper):
        """Value outside left deadzone should be scaled."""
        result = mapper._apply_deadzone(0.5, 0.1, "left")
        # Value is well above deadzone
        assert result > 0.0
    
    def test_right_deadzone_in_zone(self, mapper):
        """Value within right deadzone should return 1."""
        result = mapper._apply_deadzone(0.98, 0.1, "right")
        assert result == 1.0
    
    def test_ends_deadzone_left_end(self, mapper):
        """Value in left end of ends deadzone."""
        result = mapper._apply_deadzone(-0.98, 0.1, "ends")
        assert result == -1.0
    
    def test_ends_deadzone_right_end(self, mapper):
        """Value in right end of ends deadzone."""
        result = mapper._apply_deadzone(0.98, 0.1, "ends")
        assert result == 1.0
    
    def test_no_deadzone(self, mapper):
        """Zero deadzone should not affect value."""
        result = mapper._apply_deadzone(0.5, 0.0, "center")
        assert result == 0.5


class TestResponseCurves:
    """Tests for response curve application."""
    
    @pytest.fixture
    def mapper(self):
        mock_conn = MockXPlaneConnection()
        return InputMapper(mock_conn)
    
    def test_linear_curve(self, mapper):
        """Linear curve should not modify value."""
        assert mapper._apply_curve(0.5, "linear") == 0.5
        assert mapper._apply_curve(-0.5, "linear") == -0.5
        assert mapper._apply_curve(1.0, "linear") == 1.0
    
    def test_aggressive_curve(self, mapper):
        """Aggressive curve (sqrt) should increase sensitivity near center."""
        result = mapper._apply_curve(0.25, "aggressive")
        # sqrt(0.25) = 0.5
        assert abs(result - 0.5) < 0.01
    
    def test_soft_curve(self, mapper):
        """Soft curve (squared) should decrease sensitivity near center."""
        result = mapper._apply_curve(0.5, "soft")
        # 0.5^2 = 0.25
        assert abs(result - 0.25) < 0.01
    
    def test_smooth_curve(self, mapper):
        """Smooth curve (x^1.5) should be between linear and soft."""
        result = mapper._apply_curve(0.5, "smooth")
        # 0.5^1.5 ≈ 0.354
        assert 0.35 < result < 0.36
    
    def test_ultra_fine_curve(self, mapper):
        """Ultra fine curve (x^3) should be very sensitive near center."""
        result = mapper._apply_curve(0.5, "ultra_fine")
        # 0.5^3 = 0.125
        assert abs(result - 0.125) < 0.01
    
    def test_s_curve(self, mapper):
        """S-curve should ease in and out."""
        # At midpoint, smoothstep should be 0.5
        result = mapper._apply_curve(0.5, "s_curve")
        assert abs(result - 0.5) < 0.01
        
        # Near 0, should be close to 0
        result_low = mapper._apply_curve(0.1, "s_curve")
        assert result_low < 0.1
        
        # Near 1, should be close to 1
        result_high = mapper._apply_curve(0.9, "s_curve")
        assert result_high > 0.9
    
    def test_exponential_curve(self, mapper):
        """Exponential curve should accelerate toward end."""
        result = mapper._apply_curve(0.5, "exponential")
        # (e^0.5 - 1) / (e - 1) ≈ 0.382
        assert 0.35 < result < 0.40
    
    def test_curves_preserve_sign(self, mapper):
        """All curves should preserve the sign of input."""
        for curve in ["linear", "aggressive", "soft", "smooth", "ultra_fine", "s_curve", "exponential"]:
            pos_result = mapper._apply_curve(0.5, curve)
            neg_result = mapper._apply_curve(-0.5, curve)
            assert pos_result > 0
            assert neg_result < 0
            assert abs(pos_result) == abs(neg_result)
    
    def test_curves_at_extremes(self, mapper):
        """Curves should return ±1 at extremes."""
        for curve in ["linear", "aggressive", "soft", "smooth", "ultra_fine", "s_curve", "exponential"]:
            assert abs(mapper._apply_curve(1.0, curve) - 1.0) < 0.01
            assert abs(mapper._apply_curve(-1.0, curve) + 1.0) < 0.01


class TestAxisProcessing:
    """Tests for complete axis processing pipeline."""
    
    @pytest.fixture
    def mapper(self):
        mock_conn = MockXPlaneConnection()
        return InputMapper(mock_conn)
    
    def test_full_axis_processing(self, mapper):
        """Test complete axis processing with all features."""
        mapping = InputMapping(
            input_key="AXIS_0",
            device_port="TEST",
            action=InputAction.AXIS,
            target="sim/test/throttle",
            axis_min=-1.0,
            axis_max=1.0,
            axis_deadzone=0.1,
            axis_deadzone_pos="center",
            axis_curve="linear",
            axis_invert=False,
            min_value=0.0,
            max_value=1.0
        )
        
        # Test center (0 input -> 0.5 output for 0-1 range)
        result = mapper._apply_axis_processing(0.0, mapping)
        assert abs(result - 0.5) < 0.01
        
        # Test full positive
        result = mapper._apply_axis_processing(1.0, mapping)
        assert abs(result - 1.0) < 0.01
    
    def test_axis_invert(self, mapper):
        """Test axis inversion."""
        mapping = InputMapping(
            input_key="AXIS_0",
            device_port="TEST",
            action=InputAction.AXIS,
            target="sim/test/throttle",
            axis_min=-1.0,
            axis_max=1.0,
            axis_deadzone=0.0,
            axis_deadzone_pos="center",
            axis_curve="linear",
            axis_invert=True,
            min_value=0.0,
            max_value=1.0
        )
        
        # Positive input should map to lower output when inverted
        result = mapper._apply_axis_processing(1.0, mapping)
        assert abs(result - 0.0) < 0.01


class TestSequenceActions:
    """Tests for sequence/macro functionality."""
    
    @pytest.fixture
    def mapper(self):
        mock_conn = MockXPlaneConnection()
        return InputMapper(mock_conn)
    
    @pytest.mark.asyncio
    async def test_sequence_action_to_dict(self):
        """Test SequenceAction serialization."""
        action = SequenceAction(
            action_type="command",
            target="sim/autopilot/toggle",
            value=1.0,
            delay_ms=500
        )
        
        data = action.to_dict()
        assert data["action_type"] == "command"
        assert data["target"] == "sim/autopilot/toggle"
        assert data["delay_ms"] == 500
    
    @pytest.mark.asyncio
    async def test_sequence_action_from_dict(self):
        """Test SequenceAction deserialization."""
        data = {
            "action_type": "dataref",
            "target": "sim/test/value",
            "value": 0.5,
            "delay_ms": 100
        }
        
        action = SequenceAction.from_dict(data)
        assert action.action_type == "dataref"
        assert action.target == "sim/test/value"
        assert action.value == 0.5
        assert action.delay_ms == 100
    
    @pytest.mark.asyncio
    async def test_execute_sequence_action_command(self, mapper):
        """Test executing a command sequence action."""
        action = SequenceAction(
            action_type="command",
            target="sim/autopilot/heading_up",
            value=0.0,
            delay_ms=0
        )
        
        await mapper._execute_sequence_action(action, 1)
        
        assert "sim/autopilot/heading_up" in mapper.xplane_conn.sent_commands
    
    @pytest.mark.asyncio
    async def test_execute_sequence_action_dataref(self, mapper):
        """Test executing a dataref sequence action."""
        action = SequenceAction(
            action_type="dataref",
            target="sim/cockpit2/controls/flap_ratio",
            value=0.5,
            delay_ms=0
        )
        
        await mapper._execute_sequence_action(action, 1)
        
        assert ("sim/cockpit2/controls/flap_ratio", 0.5) in mapper.xplane_conn.written_datarefs


class TestInputMappingSerialization:
    """Tests for InputMapping to_dict and from_dict."""
    
    def test_mapping_to_dict(self):
        """Test serialization of full mapping."""
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="WINMM_0",
            action=InputAction.DATAREF_TOGGLE,
            target="sim/cockpit/gear",
            condition_enabled=True,
            condition_dataref="sim/airspeed",
            condition_operator="<",
            condition_value=200.0,
            axis_deadzone=0.1,
            axis_deadzone_pos="center",
            axis_curve="aggressive",
            description="Gear Toggle (Safe Speed)"
        )
        
        data = mapping.to_dict()
        
        assert data["input_key"] == "BTN_0"
        assert data["action"] == "DATAREF_TOGGLE"
        assert data["condition_enabled"] is True
        assert data["condition_operator"] == "<"
        assert data["axis_curve"] == "aggressive"
    
    def test_mapping_from_dict(self):
        """Test deserialization of mapping."""
        data = {
            "input_key": "AXIS_0",
            "device_port": "WINMM_0",
            "action": "AXIS",
            "target": "sim/throttle",
            "condition_enabled": False,
            "axis_deadzone": 0.05,
            "axis_deadzone_pos": "left",
            "axis_curve": "smooth",
            "axis_invert": True,
            "min_value": 0.0,
            "max_value": 1.0,
            "description": "Throttle"
        }
        
        mapping = InputMapping.from_dict(data)
        
        assert mapping.input_key == "AXIS_0"
        assert mapping.action == InputAction.AXIS
        assert mapping.axis_deadzone == 0.05
        assert mapping.axis_deadzone_pos == "left"
        assert mapping.axis_curve == "smooth"
        assert mapping.axis_invert is True
    
    def test_mapping_roundtrip(self):
        """Test that to_dict -> from_dict preserves all data."""
        original = InputMapping(
            input_key="BTN_5",
            device_port="COM3",
            action=InputAction.SEQUENCE,
            target="",
            sequence_actions=[
                SequenceAction("command", "sim/gear/down", 0, 0),
                SequenceAction("dataref", "sim/flaps", 0.5, 500),
            ],
            sequence_stop_on_error=True,
            sequence_repeat_while_held=False,
            sequence_reverse_on_release=True,
            condition_enabled=True,
            condition_dataref="sim/speed",
            condition_operator="<=",
            condition_value=150.0,
            description="Landing Config"
        )
        
        data = original.to_dict()
        restored = InputMapping.from_dict(data)
        
        assert restored.input_key == original.input_key
        assert restored.action == original.action
        assert len(restored.sequence_actions) == 2
        assert restored.sequence_stop_on_error is True
        assert restored.sequence_reverse_on_release is True
        assert restored.condition_enabled is True
        assert restored.condition_value == 150.0


class TestProcessInput:
    """Integration tests for process_input."""
    
    @pytest.fixture
    def mapper(self):
        mock_conn = MockXPlaneConnection()
        mapper = InputMapper(mock_conn)
        return mapper
    
    @pytest.mark.asyncio
    async def test_process_command_on_press(self, mapper):
        """Command should only fire on button press (value > 0)."""
        mapping = InputMapping(
            input_key="BTN_0",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/test/command"
        )
        mapper.add_mapping(mapping)
        
        # Press
        await mapper.process_input("TEST", "BTN_0", 1.0)
        assert len(mapper.xplane_conn.sent_commands) == 1
        
        # Release (should not fire again)
        await mapper.process_input("TEST", "BTN_0", 0.0)
        assert len(mapper.xplane_conn.sent_commands) == 1
    
    @pytest.mark.asyncio
    async def test_process_dataref_set(self, mapper):
        """DATAREF_SET should set value_on on press, value_off on release."""
        mapping = InputMapping(
            input_key="SW_0",
            device_port="TEST",
            action=InputAction.DATAREF_SET,
            target="sim/test/switch",
            value_on=1.0,
            value_off=0.0
        )
        mapper.add_mapping(mapping)
        
        # Press
        await mapper.process_input("TEST", "SW_0", 1.0)
        assert ("sim/test/switch", 1.0) in mapper.xplane_conn.written_datarefs
        
        # Release
        await mapper.process_input("TEST", "SW_0", 0.0)
        assert ("sim/test/switch", 0.0) in mapper.xplane_conn.written_datarefs
    
    @pytest.mark.asyncio
    async def test_process_with_failed_condition(self, mapper):
        """Action should be blocked when condition fails."""
        mapping = InputMapping(
            input_key="BTN_GEAR",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/gear/toggle",
            condition_enabled=True,
            condition_dataref="sim/airspeed",
            condition_operator="<",
            condition_value=200.0
        )
        mapper.add_mapping(mapping)
        
        # Set airspeed above limit
        mapper.update_current_value("sim/airspeed", 250.0)
        
        # Try to trigger
        await mapper.process_input("TEST", "BTN_GEAR", 1.0)
        
        # Command should NOT have been sent
        assert len(mapper.xplane_conn.sent_commands) == 0
    
    @pytest.mark.asyncio
    async def test_process_with_passing_condition(self, mapper):
        """Action should execute when condition passes."""
        mapping = InputMapping(
            input_key="BTN_GEAR",
            device_port="TEST",
            action=InputAction.COMMAND,
            target="sim/gear/toggle",
            condition_enabled=True,
            condition_dataref="sim/airspeed",
            condition_operator="<",
            condition_value=200.0
        )
        mapper.add_mapping(mapping)
        
        # Set airspeed below limit
        mapper.update_current_value("sim/airspeed", 150.0)
        
        # Trigger
        await mapper.process_input("TEST", "BTN_GEAR", 1.0)
        
        # Command SHOULD have been sent
        assert "sim/gear/toggle" in mapper.xplane_conn.sent_commands


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
