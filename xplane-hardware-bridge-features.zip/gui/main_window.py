from __future__ import annotations
import logging
import asyncio
from core.input_mapper import InputMapper
from core.profile_manager import ProfileManager
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QLabel, QStatusBar, QPushButton,
    QMessageBox, QMenu, QMenuBar, QInputDialog
)
from PyQt6.QtGui import QAction
from PyQt6.QtCore import Qt, QTimer, pyqtSignal

from core.hid.hid_manager import HIDManager
from core.arduino.arduino_manager import ArduinoManager

from .arduino_panel import ArduinoPanel
from .output_panel import OutputPanel
from .settings_panel import SettingsPanel
from .input_panel import InputPanel

log = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    """Main application window."""

    # Signals for thread-safe communication
    arduino_input_signal = pyqtSignal(str, str, float)  # port, key, value

    def __init__(
        self,
        xplane_conn,
        dataref_manager,
        arduino_manager: ArduinoManager,
        hid_manager: HIDManager,
    ) -> None:
        super().__init__()

        self.xplane_conn = xplane_conn
        self.dataref_manager = dataref_manager
        self.arduino_manager = arduino_manager
        self.hid_manager = hid_manager

        # Create input mapper with dataref manager for condition tracking
        self.input_mapper = InputMapper(xplane_conn, dataref_manager)

        # Create profile manager
        self.profile_manager = ProfileManager(arduino_manager, self.input_mapper, xplane_conn)

        self._setup_ui()
        self._setup_menu()
        self._setup_status_bar()
        self._setup_callbacks()
        self._start_managers()

        # Connect the signal to the async handler
        self.arduino_input_signal.connect(self._handle_arduino_input)
        
        # Status update timer
        self._status_timer = QTimer()
        self._status_timer.timeout.connect(self._update_status)
        self._status_timer.start(1000)

        # Load default profile on startup
        QTimer.singleShot(500, self._load_default_profile)
    
    def _load_default_profile(self):
        """Load default profile after startup."""
        if self.profile_manager.load_profile("default"):
            log.info("Loaded default profile")
            if hasattr(self, 'output_panel'):
                self.output_panel.refresh_from_manager()
        else:
            log.info("No default profile found (fresh start)")

    def _setup_ui(self) -> None:
        self.setWindowTitle("X-Plane Dataref Bridge")
        self.setMinimumSize(900, 600)
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        
        layout = QVBoxLayout(central)
        
        # Connection status bar at top
        status_layout = QHBoxLayout()
        
        self.xplane_status = QLabel("X-Plane: Disconnected")
        self.xplane_status.setStyleSheet("color: red; font-weight: bold;")
        status_layout.addWidget(self.xplane_status)
        
        status_layout.addStretch()
        
        self.connect_btn = QPushButton("Connect to X-Plane")
        self.connect_btn.clicked.connect(self._toggle_xplane_connection)
        status_layout.addWidget(self.connect_btn)
        
        layout.addLayout(status_layout)
        
        # Tab widget
        self.tabs = QTabWidget()
        
        # Output Config panel (Data Center)
        self.output_panel = OutputPanel(self.dataref_manager, self.xplane_conn, self.arduino_manager)
        self.tabs.addTab(self.output_panel, "Output Config")

        # Input Config panel (Controller Lab)
        self.input_panel = InputPanel(self.hid_manager, self.input_mapper, self.profile_manager)
        self.tabs.addTab(self.input_panel, "Input Config")

        # Hardware panel (Device Manager - Arduino/Serial devices)
        self.arduino_panel = ArduinoPanel(self.arduino_manager, self.dataref_manager)
        self.tabs.addTab(self.arduino_panel, "Hardware")

        # Settings panel
        self.settings_panel = SettingsPanel()
        self.tabs.addTab(self.settings_panel, "Settings")

        layout.addWidget(self.tabs)

    def _setup_menu(self) -> None:
        menu_bar = self.menuBar()
        
        # File Menu
        file_menu = menu_bar.addMenu("File")
        
        save_action = QAction("Save Profile", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self._save_profile_dialog)
        file_menu.addAction(save_action)
        
        load_action = QAction("Load Profile", self)
        load_action.setShortcut("Ctrl+O")
        load_action.triggered.connect(self._load_profile_dialog)
        file_menu.addAction(load_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

    def _save_profile_dialog(self):
        name, ok = QInputDialog.getText(self, "Save Profile", "Profile Name:", text="default")
        if ok and name:
            if self.profile_manager.save_profile(name):
                self.status_bar.showMessage(f"Profile '{name}' saved successfully", 3000)
            else:
                QMessageBox.critical(self, "Error", "Failed to save profile")

    def _load_profile_dialog(self):
        name, ok = QInputDialog.getText(self, "Load Profile", "Profile Name:", text="default")
        if ok and name:
            if self.profile_manager.load_profile(name):
                self.status_bar.showMessage(f"Profile '{name}' loaded successfully", 3000)
                # Refresh UI
                if hasattr(self, 'output_panel'):
                    self.output_panel.refresh_from_manager()
            else:
                QMessageBox.warning(self, "Error", f"Profile '{name}' not found or failed to load")

    def _setup_status_bar(self) -> None:
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")

    def _on_arduino_input_received(self, port: str, key: str, value: float) -> None:
        """
        Called from Arduino manager thread when input is received.
        Emits a signal to handle it in the main thread.
        """
        self.arduino_input_signal.emit(port, key, value)

    def _handle_arduino_input(self, port: str, key: str, value: float) -> None:
        """
        Handle Arduino input in the main thread (slot for the signal).
        """
        log.debug("Arduino input: %s/%s = %.2f", port, key, value)

        # 1. Pass to Input Panel for "Learn" mode
        if value != 0:  # Press or Rotate
            self.input_panel.handle_input_signal(key, port)

        # 2. Process actual logic
        asyncio.create_task(self._process_arduino_input(port, key, value))

    async def _process_arduino_input(self, port: str, key: str, value: float) -> None:
        """Process Arduino input asynchronously."""
        try:
            await self.input_mapper.process_input(port, key, value)
        except Exception as e:
            log.error("Error processing input %s: %s", key, e)

    def _setup_callbacks(self) -> None:
        """Setup callbacks for managers."""
        # X-Plane connection status
        self.xplane_conn.on_connection_changed = self._on_xplane_connection_changed

        # X-Plane dataref updates -> bridge -> Arduino devices
        self.xplane_conn.on_dataref_update = self._on_dataref_update

        # Arduino input -> emit signal (thread-safe)
        self.arduino_manager.on_input_received = self._on_arduino_input_received

        # Arduino DREF/CMD commands -> X-Plane
        self.arduino_manager.on_dataref_write = self._on_arduino_dataref_write
        self.arduino_manager.on_command_send = self._on_arduino_command_send

    def _on_arduino_dataref_write(self, dataref: str, value: float) -> None:
        """Handle dataref write request from Arduino."""
        if self.xplane_conn.connected:
            asyncio.create_task(self.xplane_conn.write_dataref(dataref, value))

    def _on_arduino_command_send(self, command: str) -> None:
        """Handle command send request from Arduino."""
        if self.xplane_conn.connected:
            asyncio.create_task(self.xplane_conn.send_command(command))

    def _start_managers(self) -> None:
        """Start background managers."""
        self.hid_manager.start()
        log.info("Managers started")

    def _toggle_xplane_connection(self) -> None:
        """Toggle X-Plane connection."""
        asyncio.create_task(self._async_toggle_connection())

    async def _async_toggle_connection(self) -> None:
        """Async connection toggle."""
        if self.xplane_conn.connected:
            await self.xplane_conn.disconnect()
        else:
            # Get settings
            ip = self.settings_panel.get_xplane_ip()
            send_port = self.settings_panel.get_xplane_port()
            recv_port = self.settings_panel.get_recv_port()

            self.xplane_conn.ip = ip
            self.xplane_conn.port = send_port
            self.xplane_conn.recv_port = recv_port

            success = await self.xplane_conn.connect()

            if success:
                # Subscribe to condition datarefs from all mappings
                self._subscribe_condition_datarefs()
            else:
                QMessageBox.warning(
                    self,
                    "Connection Failed",
                    f"Failed to connect to X-Plane.\n\n"
                    f"Sending to: {ip}:{send_port}\n"
                    f"Receiving on port: {recv_port}\n\n"
                    "Make sure X-Plane is running."
                )

    def _subscribe_condition_datarefs(self) -> None:
        """Subscribe to all datarefs used in conditions."""
        subscribed = set()
        
        for mapping in self.input_mapper.get_mappings():
            if mapping.condition_enabled and mapping.condition_dataref:
                if mapping.condition_dataref not in subscribed:
                    asyncio.create_task(
                        self.xplane_conn.subscribe_dataref(mapping.condition_dataref, 5)
                    )
                    subscribed.add(mapping.condition_dataref)
                    log.info("Subscribed to condition dataref: %s", mapping.condition_dataref)

    def _on_xplane_connection_changed(self, connected: bool) -> None:
        """Handle X-Plane connection state change."""
        if connected:
            self.xplane_status.setText("X-Plane: Connected")
            self.xplane_status.setStyleSheet("color: green; font-weight: bold;")
            self.connect_btn.setText("Disconnect")
            self.status_bar.showMessage("Connected to X-Plane")
        else:
            self.xplane_status.setText("X-Plane: Disconnected")
            self.xplane_status.setStyleSheet("color: red; font-weight: bold;")
            self.connect_btn.setText("Connect to X-Plane")
            self.status_bar.showMessage("Disconnected from X-Plane")

    def _on_dataref_update(self, dataref: str, value: float) -> None:
        """Handle dataref update from X-Plane."""
        # Update Output Panel
        self.output_panel.on_dataref_update(dataref, value)

        # Forward to Arduino Manager (Universal Mappings handled inside manager now)
        self.arduino_manager.on_dataref_update(dataref, value)

        # Update input mapper (for condition evaluation and toggle tracking)
        self.input_mapper.update_current_value(dataref, value)

    def _update_status(self) -> None:
        """Periodic status update."""
        # Count connected devices
        arduino_count = sum(
            1 for d in self.arduino_manager.devices_snapshot().values()
            if d.is_connected
        )
        hid_count = sum(
            1 for d in self.hid_manager.devices_snapshot().values()
            if d.connected
        )

        parts = []
        if self.xplane_conn.connected:
            parts.append("X-Plane: OK")
        if arduino_count > 0:
            parts.append(f"Arduino: {arduino_count}")
        if hid_count > 0:
            parts.append(f"HID: {hid_count}")

        if parts:
            self.status_bar.showMessage(" | ".join(parts))
    
    def closeEvent(self, event) -> None:
        """Handle window close."""
        log.info("Shutting down...")

        # Save profile on exit
        self.profile_manager.save_profile("default")
        log.info("Saved default profile")

        # Disconnect X-Plane
        if self.xplane_conn.connected:
            asyncio.create_task(self.xplane_conn.disconnect())

        self.hid_manager.stop()
        self.arduino_manager.disconnect_all()

        event.accept()
